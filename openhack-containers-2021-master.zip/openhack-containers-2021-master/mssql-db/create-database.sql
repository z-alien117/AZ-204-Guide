 
CREATE DATABASE mydrivingDB;
GO

USE mydrivingDB;
GO

CREATE TABLE Products (ID int, ProductName nvarchar(max));
GO