# Challenge #3  Solution

1. Execute `./deploy-azure.sh`

2. Execute `./deploy-app.sh`.

3. Setting up security 

`security-int.sh`

`k8s/security/setup-security.sh`